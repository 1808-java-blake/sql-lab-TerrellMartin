package com.revature.day5;

public class CalculatorImpl implements Calculator{

	@Override
	public double add(double in1, double in2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double subtract(double in1, double in2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double multiply(double in1, double in2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double divide(double in1, double in2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double pow(double base, double exp) {
		// TODO Auto-generated method stub
		return 0;
	}

}
