package com.revature.day4;

public interface MyRecreationOfList<T> {

	void add(T o);
	T get(Number n);
}
