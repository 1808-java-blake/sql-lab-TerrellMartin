package com.revature.day1;

public class AccessModifiers {
	private int secretField;
	int lessSecretField;
	protected int notVerySecretField;
	public int notAtAllSecretField;
	
	public int getSecretField() {
		return secretField;
	}
	
}
