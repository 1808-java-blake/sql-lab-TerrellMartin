package com.revature.day4;

public class ThreadLauncher {
	public static void main(String[] args) throws InterruptedException {
		System.out.println(Thread.currentThread().getName());
//		Thread t = new MyThread();
//		System.out.println(t.getState());
//		t.start();
//		System.out.println(t.getState());
//		for(int j = 0; j <= 1000000; j++) {
//			System.out.println("j = " + j);
//		}
		
		
//		Thread t = new Thread(new MyRunnable());
//		t.start();
//		Thread.sleep(1000);
//		System.out.println(t.getState());
		
		
//		BlockingUtil bu = new BlockingUtil();
//		Thread t1 = new Thread(new BlockingRunnable(bu));
//		Thread t2 = new Thread(new BlockingRunnable(bu));
//		t1.start();
//		t2.start();
//		Thread.sleep(1000);
//		System.out.println(t1.getState());
//		System.out.println(t2.getState());
		
		
//		Thread t1 = new Thread(new WatingThread());
//		t1.start();
//		Thread.currentThread().sleep(1000);
//		System.out.println(t1.getState());
//		t1.interrupt();
//		System.out.println("interrupting");
//		Thread.sleep(1000);
//		System.out.println(t1.getState());
		
//		Thread t1 = new Thread(new MyRunnable());
//		Thread t2 = new Thread(new JoiningThread(t1));
//		t1.start();
//		t2.start();
//		Thread.currentThread().sleep(500);
//		System.out.println(t2.getState());
		
//		Thread t1 = new Thread();
		
		Thread t = new Thread(() -> {
			while(true) {
				System.out.println("hello");
			}
		});
		t.start();
		while(true) {
			System.out.println("world");
		}
		
	}
}
