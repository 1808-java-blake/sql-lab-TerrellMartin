package com.revature.other;

import com.revature.day1.AccessModifiers;

public class AcessModifierLauncher {
	public static void main(String[] args) {
		AccessModifiers am = new AccessModifiers();
	}
}
