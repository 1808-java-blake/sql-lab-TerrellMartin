-- DQL - selects
SET SCHEMA 'weapon_store';
SELECT * FROM app_users;

SELECT * FROM weapons;
--DELETE FROM app_users 
--	WHERE username = 'Mubaraq';


--UPDATE app_users SET pass = 'pass' WHERE username = 'Kevin';